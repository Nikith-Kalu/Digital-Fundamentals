function out = dategen(k)
out = randi(365,1,k);
end